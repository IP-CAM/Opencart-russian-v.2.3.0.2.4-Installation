<?php
// Text
$_['text_footer'] 	= '<a target="_blank" href="https://ocstore.com/?utm_source=ocstore23">ocStore</a> &copy; 2009-' . date('Y') . ' All Rights Reserved.';
$_['text_version'] 	= 'Version ocStore %s<br/>Best perfomance <a target="_blank" href="https://turbohost.pro/?utm_source=ocstore23">TurboHost.pro</a>';